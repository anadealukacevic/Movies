//
//  MovieTableViewController.swift
//  Movie
//
//  Created by Anadea on 26/08/2020.
//  Copyright © 2020 Anadea. All rights reserved.
//

import UIKit

class MovieTableViewController: UITableViewController {
    
    var listOfMovies = [TopRatedMovie]() {
        didSet {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    var listOfPopularMovies = [PopularMovie]() {
        didSet {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    let sections: [String] = ["TOP RATED MOVIES", "POPULAR MOVIES"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "MOVIES"
        getDataFromServices()
    }
    
    private func getDataFromServices() {
        let movieRequestTopRated = MovieRequest(movie: "/movie/top_rated")
        movieRequestTopRated.getTopRatedMovies { [weak self] result in
            switch result {
            case .failure(let error):
                print(error)
            case .success(let movies):
                self?.listOfMovies = movies
            }
        }
        
        let movieRequestPopular = MovieRequest(movie: "/movie/popular")
        movieRequestPopular.getPopularMovies { [weak self] result in
            switch result {
            case .failure(let error):
                print(error)
            case .success(let movies):
                self?.listOfPopularMovies = movies
            }
        }
    }
}

// MARK: - TableView Data Source and Delegate
extension MovieTableViewController {
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch (section) {
        case 0:
            return listOfMovies.count
        case 1:
            return listOfPopularMovies.count
        default:
            return listOfMovies.count
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "MovieTableViewCell"
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? MovieTableViewCell else {
            fatalError("Error")
        }
        
        switch (indexPath.section) {
        case 0:
            let items = listOfMovies[indexPath.row]
            cell.movieTitle.text = items.title
            do {
                let url = URL(string: "https://image.tmdb.org/t/p/w92\(items.poster_path)")
                let data = try Data(contentsOf: url!)
                cell.posterImage.image = UIImage(data: data)
            } catch {
                print(error)
            }
        case 1:
            let items = listOfPopularMovies[indexPath.row]
            cell.movieTitle.text = items.title
            do {
                let url = URL(string: "https://image.tmdb.org/t/p/w92\(items.poster_path)")
                let data = try Data(contentsOf: url!)
                cell.posterImage.image = UIImage(data: data)
            } catch {
                print(error)
            }
        default:
            NSLog("Default possibility")
        }
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let movieDetailViewController = storyboard?.instantiateViewController(withIdentifier: "MovieDetailViewController") as? MovieDetailViewController
        self.navigationController?.pushViewController(movieDetailViewController!, animated: true)
        
        switch (indexPath.section) {
        case 0:
            movieDetailViewController?.id = listOfMovies[indexPath.row].id
            movieDetailViewController?.movieTitle = listOfMovies[indexPath.row].title
            movieDetailViewController?.releaseDate = listOfMovies[indexPath.row].release_date
            movieDetailViewController?.overview = listOfMovies[indexPath.row].overview
            movieDetailViewController?.genres = listOfMovies[indexPath.row].genre_ids
            do {
                let posterImageUrl = URL(string: "https://image.tmdb.org/t/p/w92\(listOfMovies[indexPath.row].poster_path)")
                let posterImageData = try Data(contentsOf: posterImageUrl!)
                movieDetailViewController?.posterPicture = UIImage(data: posterImageData)!
                
                let backdropImageUrl = URL(string: "https://image.tmdb.org/t/p/w300\(listOfMovies[indexPath.row].backdrop_path)")
                let backdropData = try Data(contentsOf: backdropImageUrl!)
                movieDetailViewController?.backdropImage = UIImage(data: backdropData)!
            } catch {
                print(error)
            }
        case 1:
            movieDetailViewController?.id = listOfPopularMovies[indexPath.row].id
            movieDetailViewController?.movieTitle = listOfPopularMovies[indexPath.row].title
            movieDetailViewController?.releaseDate = listOfPopularMovies[indexPath.row].release_date
            movieDetailViewController?.overview = listOfPopularMovies[indexPath.row].overview
            movieDetailViewController?.genres = listOfPopularMovies[indexPath.row].genre_ids
            do {
                let posterImageUrl = URL(string: "https://image.tmdb.org/t/p/w92\(listOfPopularMovies[indexPath.row].poster_path)")
                let data = try Data(contentsOf: posterImageUrl!)
                movieDetailViewController?.posterPicture = UIImage(data: data)!
                
                let backdropImageUrl = URL(string: "https://image.tmdb.org/t/p/w300\(listOfPopularMovies[indexPath.row].backdrop_path)")
                let backdropData = try Data(contentsOf: backdropImageUrl!)
                movieDetailViewController?.backdropImage = UIImage(data: backdropData)!
            } catch {
                print(error)
            }
        default:
            NSLog("Default possibility")
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sections[section]
    }
}
