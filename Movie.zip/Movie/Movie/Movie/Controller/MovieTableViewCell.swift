//
//  MovieTableViewCell.swift
//  Movie
//
//  Created by Anadea on 26/08/2020.
//  Copyright © 2020 Anadea. All rights reserved.
//

import UIKit

class MovieTableViewCell: UITableViewCell {
    @IBOutlet weak var posterImage: UIImageView!
    @IBOutlet weak var movieTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupLayouts()
    }
    
    private func setupLayouts() {
        posterImage.layer.cornerRadius = 10
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
