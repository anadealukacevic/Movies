//
//  MovieDetailViewController.swift
//  Movie
//
//  Created by Anadea on 26/08/2020.
//  Copyright © 2020 Anadea. All rights reserved.
//

import UIKit

class MovieDetailViewController: UIViewController {
    
    @IBOutlet weak var coverImage: UIImageView!
    @IBOutlet weak var posterImage: UIImageView!
    @IBOutlet weak var releaseDateLabel: UILabel!
    @IBOutlet weak var movieTitleLabel: UILabel!
    @IBOutlet weak var genresLabel: UILabel!
    @IBOutlet weak var overviewLabel: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var id = 0
    var movieTitle = ""
    var releaseDate = ""
    var overview = ""
    var posterPicture = UIImage()
    var backdropImage = UIImage()
    var genres: [Int] = []
    
    var listOfSimilarMovies = [SimilarMovie]() {
        didSet {
            DispatchQueue.main.async {
                self.collectionView.reloadData()
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupFields()
        setupLayout()
        getDataFromServices()
        collectionView.delegate = self
        collectionView.dataSource = self
    }
    
    private func getDataFromServices() {
        let movieRequestSimilar = MovieRequest(movie: "/movie/\(id)/similar")
        movieRequestSimilar.getSimilarMovies { [weak self] result in
            switch result {
            case .failure(let error):
                print(error)
            case .success(let movies):
                self?.listOfSimilarMovies = movies
            }
        }
    }
    
    private func setupFields() {
        navigationItem.title = "\(movieTitle)"
        movieTitleLabel.text = movieTitle
        releaseDateLabel.text = releaseDate
        overviewLabel.text = overview
        genresLabel.text = "\(genres)"
        posterImage.image = posterPicture
        coverImage.image = backdropImage
    }
    
    private func setupLayout() {
        posterImage.layer.cornerRadius = 10
    }
    
}

extension MovieDetailViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listOfSimilarMovies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SimilarMovieCollectionViewCell", for: indexPath) as! SimilarMovieCollectionViewCell
        
        let items = listOfSimilarMovies[indexPath.row]
        cell.similarMovieTitleLabel.text = items.title
        do {
            let url = URL(string: "https://image.tmdb.org/t/p/w92\(items.poster_path)")
            let data = try Data(contentsOf: url!)
            cell.similarMovieImage.image = UIImage(data: data)
        } catch {
            print(error)
        }
        
        return cell
    }
    
    
}
