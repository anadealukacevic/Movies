//
//  SimilarMovieCollectionViewCell.swift
//  Movie
//
//  Created by Anadea on 27/08/2020.
//  Copyright © 2020 Anadea. All rights reserved.
//

import UIKit

class SimilarMovieCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var similarMovieImage: UIImageView!
    @IBOutlet weak var similarMovieTitleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupLayout()
    }
    
    private func setupLayout() {
        similarMovieImage.layer.cornerRadius = 22
    }
}
