//
//  PopularMovieModel.swift
//  Movie
//
//  Created by Anadea on 27/08/2020.
//  Copyright © 2020 Anadea. All rights reserved.
//

import UIKit

// MARK: - Popular Movie
struct PopularMovieResults: Codable {
    let results: [PopularMovie]
}

struct PopularMovie: Codable {
    let id: Int
    let poster_path: String
    let title: String
    let overview: String
    let backdrop_path: String
    let release_date: String
    let genre_ids: [Int]
}
