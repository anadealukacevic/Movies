//
//  MovieDetailsModel.swift
//  Movie
//
//  Created by Anadea on 27/08/2020.
//  Copyright © 2020 Anadea. All rights reserved.
//

import UIKit

// MARK: - Movie Detail
struct MovieDetail: Codable {
    let poster_path: String
    let backdrop_path: String
    let title: String
    let release_date: Date
    let genres: [Genre]
    let overview: String
}

struct Genre: Codable {
    let name: String
}
