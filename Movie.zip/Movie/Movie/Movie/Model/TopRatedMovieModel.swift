//
//  TopRatedMovieModel.swift
//  Movie
//
//  Created by Anadea on 27/08/2020.
//  Copyright © 2020 Anadea. All rights reserved.
//

import UIKit

// MARK: - Top Rated Movie
struct TopRatedMovieResults: Codable {
    let results: [TopRatedMovie]
}

struct TopRatedMovie: Codable {
    let id: Int
    let poster_path: String
    let title: String
    
    let overview: String
    let backdrop_path: String
    let release_date: String
    let genre_ids: [Int]
}
