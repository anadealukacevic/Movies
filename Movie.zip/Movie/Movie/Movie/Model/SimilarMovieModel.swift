//
//  MovieModel.swift
//  Movie
//
//  Created by Anadea on 26/08/2020.
//  Copyright © 2020 Anadea. All rights reserved.
//

import UIKit

// MARK: - Similar Movie
struct SimilarMovieResults: Codable {
    let results: [SimilarMovie]
}

struct SimilarMovie: Codable {
    let poster_path: String
    let title: String
}
