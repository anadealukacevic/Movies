//
//  MovieService.swift
//  Movies
//
//  Created by Anadea on 26/08/2020.
//  Copyright © 2020 Anadea. All rights reserved.
//

import Foundation

enum MovieError: Error {
    case noDataAvailable
    case canNotProcessData
}

struct MovieRequest {
    let resourceURL: URL
    let API_KEY = "fe3b8cf16d78a0e23f0c509d8c37caad"
    
    init(movie: String) {
        let resourceString = "https://api.themoviedb.org/3\(movie)?api_key=\(API_KEY)"
        
        guard let resourceURL = URL(string: resourceString) else {fatalError()}
        self.resourceURL = resourceURL
        
    }
    
    func getTopRatedMovies(completion: @escaping(Result<[TopRatedMovie], MovieError>) -> Void) {
        let dataTask = URLSession.shared.dataTask(with: resourceURL) { data, _, _ in
            guard let jsonData = data else {
                completion(.failure(.noDataAvailable))
                return
            }
            do {
                let decoder = JSONDecoder()
                let topRatedMovieResults = try decoder.decode(TopRatedMovieResults.self, from: jsonData)
                let topRatedMovies = topRatedMovieResults.results
                completion(.success(topRatedMovies))
                print("TOP RATED MOVIES: ", topRatedMovies)
            } catch {
                completion(.failure(.canNotProcessData))
            }
        }
        dataTask.resume()
    }
    
    func getPopularMovies(completion: @escaping(Result<[PopularMovie], MovieError>) -> Void) {
        let dataTask = URLSession.shared.dataTask(with: resourceURL) { data, _, _ in
            guard let jsonData = data else {
                completion(.failure(.noDataAvailable))
                return
            }
            do {
                let decoder = JSONDecoder()
                let popularMovieResults = try decoder.decode(PopularMovieResults.self, from: jsonData)
                let popularMovies = popularMovieResults.results
                completion(.success(popularMovies))
                print("POPULAR MOVIES: ", popularMovies)
            } catch {
                completion(.failure(.canNotProcessData))
            }
        }
        dataTask.resume()
    }
    
    func getSimilarMovies(completion: @escaping(Result<[SimilarMovie], MovieError>) -> Void) {
        let dataTask = URLSession.shared.dataTask(with: resourceURL) { data, _, _ in
            guard let jsonData = data else {
                completion(.failure(.noDataAvailable))
                return
            }
            do {
                let decoder = JSONDecoder()
                let similarMovieResults = try decoder.decode(SimilarMovieResults.self, from: jsonData)
                let similarMovie = similarMovieResults.results
                completion(.success(similarMovie))
                print("SIMILAR MOVIES: ", similarMovie)
            } catch {
                completion(.failure(.canNotProcessData))
            }
        }
        dataTask.resume()
    }
}
